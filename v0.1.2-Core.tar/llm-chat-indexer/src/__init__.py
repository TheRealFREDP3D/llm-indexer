"""
Source package for LLM Chat Indexer.
"""
